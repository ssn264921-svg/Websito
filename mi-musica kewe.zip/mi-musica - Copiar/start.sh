#!/usr/bin/env bash
# Arranca Mi Música cargando la configuración opcional de .env
set -e

cd "$(dirname "$0")"

if [ -f .env ]; then
  set -a
  # shellcheck disable=SC1091
  . ./.env
  set +a
fi

if [ ! -d node_modules ]; then
  echo "Instalando dependencias por primera vez…"
  npm install
fi

exec node server.js
