# 🎵 Mi Música

Biblioteca musical personal con subida de archivos, portadas y reproductor web.
Tus canciones se guardan en **tu propio servidor**, no en plataformas externas.

## Lo que incluye

- Subida de varias canciones a la vez (MP3, M4A, AAC, OGG, OPUS, WAV, FLAC, WebM).
- Portada opcional por subida y edición del título de cada canción antes de subir.
- Reproductor con cola, búsqueda, orden, aleatorio, repetición y control de volumen.
- Descarga de los archivos originales y borrado de canciones.
- Diseño adaptable a móvil, tableta y escritorio.
- Guardado real en disco: `uploads/` para los audios, `data/songs.json` para la información.
- Protección opcional con clave de administrador para subir y borrar.

## Inicio rápido

Necesitas **Node.js 18 o superior**.

```bash
cd /sdcard/Documents/mi-musica
npm install
npm start
```

También puedes usar el lanzador, que instala las dependencias la primera vez
y carga la configuración de un archivo `.env` si existe:

```bash
./start.sh
```

Para cambiar el nombre, el puerto o poner una clave, copia `.env.example` como
`.env` y edita sus valores:

```bash
cp .env.example .env
```

Abre en el navegador:

```
http://localhost:3000
```

En este dispositivo Android funciona abriendo esa dirección en Chrome. Para
escucharlo desde otro dispositivo de la misma red Wi-Fi, usa la dirección IP
del teléfono, por ejemplo:

```
http://192.168.1.50:3000
```

> El servidor debe seguir ejecutándose. Si cierras la terminal o la app que lo
> inició, la página dejará de responder.

## Cómo subir canciones

1. Pulsa **Subir canción**.
2. Arrastra uno o varios audios, o toca la zona para elegirlos.
3. Revisa el título de cada canción. Puedes cambiar el artista y añadir una
   portada para toda la tanda.
4. Pulsa **Subir canciones** y espera a que termine la barra de progreso.

La portada acepta JPG, PNG, WebP o GIF de hasta 8 MB. Cada audio puede pesar
hasta 100 MB por defecto.

## Configuración

Las opciones se pasan como variables de entorno al arrancar. Si usas
`./start.sh`, puedes definirlas en el archivo `.env` (copia `.env.example`).

| Variable | Por defecto | Descripción |
| --- | --- | --- |
| `PORT` | `3000` | Puerto del servidor |
| `SITE_NAME` | `Mi Música` | Nombre que aparece en la página |
| `MAX_FILE_MB` | `100` | Tamaño máximo de cada audio (MB) |
| `MAX_COVER_MB` | `8` | Tamaño máximo de cada portada (MB) |
| `ADMIN_KEY` | *(vacío)* | Clave para subir y borrar canciones |

Ejemplo:

```bash
SITE_NAME="Estudio de Ana" ADMIN_KEY="mi-clave-secreta" PORT=3000 npm start
```

Si defines `ADMIN_KEY`, la página mostrará un campo para escribirla al subir y
la pedirá al borrar. **Defínela siempre antes de abrir el servidor a internet.**

### Acceso desde internet

Para compartir la página fuera de tu red local necesitas exponer el puerto con
un túnel o un servidor. Opciones habituales:

- Túnel temporal: `cloudflared tunnel --url http://localhost:3000` (o ngrok).
- VPS o servicio de hosting con Node.js y **disco persistente**.

En servicios como Render, Railway o Fly.io los archivos se pueden perder al
redesplegar si no usas un volumen persistente. Para conservar la música,
asegúrate de montar un disco persistente y hacer copias de seguridad.

## Copias de seguridad

Copia estas dos cosas:

```
uploads/          # audios y portadas
data/songs.json   # títulos, artistas, reproducciones
```

Restaurarlas en el mismo proyecto devuelve la biblioteca completa.

## Estructura del proyecto

```
mi-musica/
├── server.js           # Servidor Express y API
├── package.json
├── public/
│   ├── index.html      # Interfaz
│   ├── styles.css      # Diseño
│   └── app.js          # Reproductor y subida
├── uploads/            # Audios (se crea al arrancar; no lo borres)
│   └── covers/         # Portadas
└── data/
    └── songs.json      # Metadatos de la biblioteca
```

No subas `uploads/`, `data/` ni `node_modules/` a un repositorio público.

## Problemas frecuentes

**El puerto 3000 está ocupado**

```bash
PORT=3001 npm start
```

**No se escucha en otro dispositivo**

Comprueba que ambos estén en la misma Wi-Fi, que uses la IP del teléfono y que
el servidor siga encendido. Algunos routers aíslan los dispositivos entre sí.

**Una canción no suena**

Verifica que el archivo se reproduzca en el reproductor del teléfono. Formatos
como MP3, M4A, WAV y OGG tienen el mejor soporte en navegadores.

**La página se ve sin estilos**

Abre la dirección con `http://`, no abras `index.html` como archivo local: el
servidor es quien entrega el audio y la API.

## API (opcional)

| Método | Ruta | Descripción |
| --- | --- | --- |
| `GET` | `/api/songs` | Lista de canciones y configuración |
| `POST` | `/api/songs` | Subir audio (`multipart/form-data`) |
| `GET` | `/api/songs/:id/stream` | Reproducir con soporte de rangos |
| `GET` | `/api/songs/:id/download` | Descargar el archivo |
| `POST` | `/api/songs/:id/play` | Sumar una reproducción |
| `DELETE` | `/api/songs/:id` | Borrar (requiere clave si está activa) |

---

Hecho para escuchar tu música sin anuncios ni distracciones.
