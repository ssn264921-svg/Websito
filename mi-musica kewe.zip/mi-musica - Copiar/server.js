import express from 'express';
import multer from 'multer';
import crypto from 'node:crypto';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PUBLIC_DIR = path.join(__dirname, 'public');
const UPLOAD_DIR = path.join(__dirname, 'uploads');
const COVER_DIR = path.join(UPLOAD_DIR, 'covers');
const DATA_DIR = path.join(__dirname, 'data');
const DATA_FILE = path.join(DATA_DIR, 'songs.json');

const PORT = Number.parseInt(process.env.PORT || '3000', 10);
const MAX_FILE_MB = Number.parseInt(process.env.MAX_FILE_MB || '100', 10);
const MAX_COVER_MB = Number.parseInt(process.env.MAX_COVER_MB || '8', 10);
const ADMIN_KEY = (process.env.ADMIN_KEY || '').trim();
const SITE_NAME = (process.env.SITE_NAME || 'Mi Música').trim();

const AUDIO_EXTENSIONS = new Set(['.mp3', '.m4a', '.aac', '.ogg', '.oga', '.opus', '.wav', '.flac', '.webm']);
const COVER_EXTENSIONS = new Set(['.jpg', '.jpeg', '.png', '.webp', '.gif']);
const AUDIO_MIME_TYPES = {
  '.mp3': 'audio/mpeg',
  '.m4a': 'audio/mp4',
  '.aac': 'audio/aac',
  '.ogg': 'audio/ogg',
  '.oga': 'audio/ogg',
  '.opus': 'audio/ogg',
  '.wav': 'audio/wav',
  '.flac': 'audio/flac',
  '.webm': 'audio/webm',
};

/* -------------------------------------------------------------------------- */
/*  Almacenamiento de datos                                                   */
/* -------------------------------------------------------------------------- */

for (const dir of [UPLOAD_DIR, COVER_DIR, DATA_DIR]) {
  fs.mkdirSync(dir, { recursive: true });
}

if (!fs.existsSync(DATA_FILE)) {
  fs.writeFileSync(DATA_FILE, '[]\n', 'utf8');
}

function readSongs() {
  try {
    const raw = fs.readFileSync(DATA_FILE, 'utf8');
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch (error) {
    console.error('No se pudo leer data/songs.json:', error.message);
    return [];
  }
}

function writeSongs(songs) {
  const tmp = `${DATA_FILE}.tmp`;
  fs.writeFileSync(tmp, `${JSON.stringify(songs, null, 2)}\n`, 'utf8');
  fs.renameSync(tmp, DATA_FILE);
}

/* -------------------------------------------------------------------------- */
/*  Utilidades                                                                */
/* -------------------------------------------------------------------------- */

function httpError(status, message) {
  const error = new Error(message);
  error.status = status;
  return error;
}

function getExtension(filename) {
  return path.extname(filename || '').toLowerCase();
}

function cleanText(value, maxLength) {
  return String(value ?? '').replace(/\s+/g, ' ').trim().slice(0, maxLength);
}

function titleFromFilename(filename) {
  const base = path.basename(filename || 'Canción', getExtension(filename));
  const title = base.replace(/[_]+/g, ' ').replace(/\s+/g, ' ').trim();
  return title || 'Canción sin título';
}

function downloadName(song) {
  const base = String(song.title || 'cancion')
    .normalize('NFKD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^\w\s-]/g, '')
    .trim()
    .replace(/\s+/g, '-')
    .slice(0, 80) || 'cancion';
  return `${base}${getExtension(song.filename)}`;
}

function publicSong(song) {
  return {
    id: song.id,
    title: song.title,
    artist: song.artist,
    duration: song.duration,
    size: song.size,
    plays: song.plays || 0,
    uploadedAt: song.uploadedAt,
    coverUrl: song.cover ? `/covers/${encodeURIComponent(song.cover)}` : null,
    streamUrl: `/api/songs/${encodeURIComponent(song.id)}/stream`,
    downloadUrl: `/api/songs/${encodeURIComponent(song.id)}/download`,
  };
}

function cleanupFiles(files) {
  const all = Object.values(files || {}).flat();
  for (const file of all) {
    if (file?.path) {
      fs.promises.unlink(file.path).catch(() => {});
    }
  }
}

function requireAdmin(req, _res, next) {
  if (ADMIN_KEY && req.get('x-admin-key') !== ADMIN_KEY) {
    return next(httpError(401, 'Clave de administrador incorrecta o faltante.'));
  }
  return next();
}

function findSong(req) {
  const songs = readSongs();
  const index = songs.findIndex((song) => song.id === req.params.id);
  if (index === -1) return { songs, index: -1, song: null };
  return { songs, index, song: songs[index] };
}

/* -------------------------------------------------------------------------- */
/*  Subida de archivos                                                        */
/* -------------------------------------------------------------------------- */

const storage = multer.diskStorage({
  destination(_req, file, cb) {
    cb(null, file.fieldname === 'cover' ? COVER_DIR : UPLOAD_DIR);
  },
  filename(_req, file, cb) {
    const ext = getExtension(file.originalname);
    cb(null, `${Date.now()}-${crypto.randomUUID()}${ext}`);
  },
});

const upload = multer({
  storage,
  limits: {
    fileSize: MAX_FILE_MB * 1024 * 1024,
    files: 2,
    fields: 10,
    fieldSize: 64 * 1024,
  },
  fileFilter(_req, file, cb) {
    const ext = getExtension(file.originalname);
    if (file.fieldname === 'audio') {
      if (!AUDIO_EXTENSIONS.has(ext)) {
        return cb(httpError(400, `Formato no compatible (${ext || 'desconocido'}). Usa MP3, M4A, WAV, FLAC, OGG u OPUS.`));
      }
      return cb(null, true);
    }
    if (file.fieldname === 'cover') {
      if (!COVER_EXTENSIONS.has(ext)) {
        return cb(httpError(400, 'La portada debe ser JPG, PNG, WebP o GIF.'));
      }
      return cb(null, true);
    }
    return cb(httpError(400, 'Campo de archivo no permitido.'));
  },
});

/* -------------------------------------------------------------------------- */
/*  Servidor                                                                  */
/* -------------------------------------------------------------------------- */

const app = express();
app.disable('x-powered-by');

app.use((_req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'SAMEORIGIN');
  res.setHeader('Referrer-Policy', 'same-origin');
  res.setHeader(
    'Content-Security-Policy',
    "default-src 'self'; img-src 'self' data: blob:; media-src 'self' blob:; style-src 'self' 'unsafe-inline'; script-src 'self'; connect-src 'self'; font-src 'self'; base-uri 'none'; form-action 'self'; frame-ancestors 'self'"
  );
  next();
});

app.use('/covers', express.static(COVER_DIR, { maxAge: '1y', immutable: true }));
app.use(express.static(PUBLIC_DIR, { extensions: ['html'] }));

app.get('/api/health', (_req, res) => {
  res.json({ ok: true, siteName: SITE_NAME });
});

app.get('/api/songs', (_req, res) => {
  const songs = readSongs().sort((a, b) => new Date(b.uploadedAt) - new Date(a.uploadedAt));
  res.json({
    songs: songs.map(publicSong),
    config: {
      siteName: SITE_NAME,
      maxFileMB: MAX_FILE_MB,
      adminRequired: Boolean(ADMIN_KEY),
    },
  });
});

app.post('/api/songs', requireAdmin, (req, res, next) => {
  upload.fields([
    { name: 'audio', maxCount: 1 },
    { name: 'cover', maxCount: 1 },
  ])(req, res, (error) => {
    if (error) {
      cleanupFiles(req.files);
      return next(error);
    }

    try {
      const audioFile = req.files?.audio?.[0];
      const coverFile = req.files?.cover?.[0];

      if (!audioFile) {
        cleanupFiles(req.files);
        return res.status(400).json({ error: 'Selecciona un archivo de audio.' });
      }

      if (coverFile && coverFile.size > MAX_COVER_MB * 1024 * 1024) {
        cleanupFiles(req.files);
        return res.status(413).json({ error: `La portada supera el límite de ${MAX_COVER_MB} MB.` });
      }

      const parsedDuration = Number(req.body?.duration);
      const duration = Number.isFinite(parsedDuration) && parsedDuration > 0 && parsedDuration < 86400
        ? Math.round(parsedDuration)
        : null;

      const song = {
        id: crypto.randomUUID(),
        title: cleanText(req.body?.title, 150) || titleFromFilename(audioFile.originalname),
        artist: cleanText(req.body?.artist, 120) || 'Artista desconocido',
        filename: audioFile.filename,
        cover: coverFile?.filename || null,
        originalName: cleanText(audioFile.originalname, 255),
        mime: AUDIO_MIME_TYPES[getExtension(audioFile.originalname)] || audioFile.mimetype || 'audio/mpeg',
        size: audioFile.size,
        duration,
        plays: 0,
        uploadedAt: new Date().toISOString(),
      };

      const songs = readSongs();
      songs.unshift(song);
      writeSongs(songs);

      res.status(201).json(publicSong(song));
    } catch (error) {
      cleanupFiles(req.files);
      next(error);
    }
  });
});

app.get('/api/songs/:id/stream', (req, res, next) => {
  const { song } = findSong(req);
  if (!song) return next(httpError(404, 'Canción no encontrada.'));

  const filePath = path.join(UPLOAD_DIR, song.filename);
  if (!fs.existsSync(filePath)) return next(httpError(404, 'El archivo de audio ya no existe.'));

  res.sendFile(filePath, {
    headers: {
      'Content-Type': song.mime || 'audio/mpeg',
      'Cache-Control': 'public, max-age=31536000, immutable',
    },
  }, (error) => {
    if (error && !res.headersSent) next(error);
  });
});

app.get('/api/songs/:id/download', (req, res, next) => {
  const { song } = findSong(req);
  if (!song) return next(httpError(404, 'Canción no encontrada.'));

  const filePath = path.join(UPLOAD_DIR, song.filename);
  if (!fs.existsSync(filePath)) return next(httpError(404, 'El archivo de audio ya no existe.'));

  res.download(filePath, downloadName(song), (error) => {
    if (error && !res.headersSent) next(error);
  });
});

app.post('/api/songs/:id/play', (req, res, next) => {
  const { songs, index } = findSong(req);
  if (index === -1) return next(httpError(404, 'Canción no encontrada.'));

  songs[index].plays = (songs[index].plays || 0) + 1;
  writeSongs(songs);
  res.json({ plays: songs[index].plays });
});

app.delete('/api/songs/:id', requireAdmin, (req, res, next) => {
  const { songs, index, song } = findSong(req);
  if (index === -1) return next(httpError(404, 'Canción no encontrada.'));

  songs.splice(index, 1);
  writeSongs(songs);

  fs.promises.unlink(path.join(UPLOAD_DIR, song.filename)).catch(() => {});
  if (song.cover) {
    fs.promises.unlink(path.join(COVER_DIR, song.cover)).catch(() => {});
  }

  res.json({ ok: true });
});

app.use('/api', (_req, res) => {
  res.status(404).json({ error: 'Ruta no encontrada.' });
});

app.use((req, res) => {
  res.status(404).send('Página no encontrada.');
});

app.use((error, _req, res, _next) => {
  if (res.headersSent) return;

  if (error instanceof multer.MulterError) {
    if (error.code === 'LIMIT_FILE_SIZE') {
      return res.status(413).json({ error: `El archivo supera el límite de ${MAX_FILE_MB} MB.` });
    }
    if (error.code === 'LIMIT_FILE_COUNT' || error.code === 'LIMIT_UNEXPECTED_FILE') {
      return res.status(400).json({ error: 'Solo puedes subir un audio y una portada a la vez.' });
    }
    return res.status(400).json({ error: `Error al subir el archivo (${error.code}).` });
  }

  const status = error.status || 500;
  if (status >= 500) console.error(error);
  res.status(status).json({ error: status >= 500 ? 'Error interno del servidor.' : error.message });
});

/* -------------------------------------------------------------------------- */
/*  Arranque                                                                  */
/* -------------------------------------------------------------------------- */

function localAddresses() {
  const addresses = [];
  try {
    for (const interfaces of Object.values(os.networkInterfaces())) {
      for (const address of interfaces || []) {
        if (address.family === 'IPv4' && !address.internal) addresses.push(address.address);
      }
    }
  } catch {
    // Algunos entornos (por ejemplo, Android) no permiten enumerar las interfaces.
  }
  return addresses;
}

const server = app.listen(PORT, '0.0.0.0', () => {
  console.log('\n🎵  ' + SITE_NAME + ' está en marcha\n');
  console.log(`    En este dispositivo:  http://localhost:${PORT}`);
  const networkAddresses = localAddresses();
  for (const address of networkAddresses) {
    console.log(`    En tu red local:     http://${address}:${PORT}`);
  }
  if (networkAddresses.length === 0) {
    console.log('    Para otros dispositivos: usa la IP de este dispositivo en tu red local.');
  }
  console.log(`\n    Límite por archivo:   ${MAX_FILE_MB} MB`);
  if (ADMIN_KEY) {
    console.log('    Clave de administrador: activada (subir y borrar requieren clave)');
  } else {
    console.log('    ⚠️  Sin clave: cualquiera que abra el sitio puede subir o borrar canciones.');
    console.log('       Define ADMIN_KEY antes de compartirlo por internet.');
  }
  console.log('');
});

server.on('error', (error) => {
  if (error.code === 'EADDRINUSE') {
    console.error(`El puerto ${PORT} ya está en uso. Prueba con: PORT=3001 npm start`);
  } else {
    console.error('No se pudo iniciar el servidor:', error.message);
  }
  process.exit(1);
});
