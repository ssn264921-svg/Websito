/* ==========================================================================
   Mi Música — lógica del reproductor y la biblioteca
   ========================================================================== */

(() => {
  'use strict';

  /* ------------------------------------------------------------------------
     Iconos
     ------------------------------------------------------------------------ */

  const ICONS = {
    play: '<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M8 5.14v13.72c0 .8.87 1.3 1.55.88l10.6-6.86a1.05 1.05 0 0 0 0-1.76L9.55 4.26A1.05 1.05 0 0 0 8 5.14Z"/></svg>',
    pause: '<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><rect x="5.5" y="4" width="4.4" height="16" rx="1.4"/><rect x="14.1" y="4" width="4.4" height="16" rx="1.4"/></svg>',
    prev: '<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M6.5 5a1 1 0 0 1 1 1v4.32l9.53-5.13A1.05 1.05 0 0 1 18.5 6.05v11.9a1.05 1.05 0 0 1-1.47.86L7.5 13.68V18a1 1 0 1 1-2 0V6a1 1 0 0 1 1-1Z"/></svg>',
    next: '<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M17.5 5a1 1 0 0 1 1 1v12a1 1 0 1 1-2 0v-4.32l-9.53 5.13A1.05 1.05 0 0 1 5.5 17.95V6.05a1.05 1.05 0 0 1 1.47-.86L16.5 10.32V6a1 1 0 0 1 1-1Z"/></svg>',
    shuffle: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M16 3h5v5"/><path d="M4 20 21 3"/><path d="M21 16v5h-5"/><path d="m15 15 6 6"/><path d="m4 4 5 5"/></svg>',
    repeat: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m17 2 4 4-4 4"/><path d="M3 11V9a4 4 0 0 1 4-4h14"/><path d="m7 22-4-4 4-4"/><path d="M21 13v2a4 4 0 0 1-4 4H3"/></svg>',
    repeat1: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m17 2 4 4-4 4"/><path d="M3 11V9a4 4 0 0 1 4-4h14"/><path d="m7 22-4-4 4-4"/><path d="M21 13v2a4 4 0 0 1-4 4H3"/><path d="M11 10h1v4"/></svg>',
    volume: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M11 5 6 9H2v6h4l5 4Z"/><path d="M15.5 8.5a5 5 0 0 1 0 7"/><path d="M18.5 5.5a9 9 0 0 1 0 13"/></svg>',
    volumeX: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M11 5 6 9H2v6h4l5 4Z"/><path d="m16 9 6 6"/><path d="m22 9-6 6"/></svg>',
    plus: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M12 5v14M5 12h14"/></svg>',
    search: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>',
    upload: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="m17 8-5-5-5 5"/><path d="M12 3v12"/></svg>',
    close: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M18 6 6 18M6 6l12 12"/></svg>',
    download: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="m7 10 5 5 5-5"/><path d="M12 15V3"/></svg>',
    trash: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 6h18"/><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/><path d="m19 6-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6M14 11v6"/></svg>',
    music: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/></svg>',
    image: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="9" cy="9" r="2"/><path d="m21 15-5-5L5 21"/></svg>',
    check: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 6 9 17l-5-5"/></svg>',
    alert: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M12 8v5"/><path d="M12 16.5h.01"/></svg>',
    shield: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10Z"/><path d="m9 12 2 2 4-4"/></svg>',
  };

  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => Array.from(root.querySelectorAll(selector));

  function setIcon(element, name) {
    if (element) element.innerHTML = ICONS[name] || '';
  }

  function icon(name, extraClass = '') {
    const span = document.createElement('span');
    span.className = `icon${extraClass ? ` ${extraClass}` : ''}`;
    span.innerHTML = ICONS[name] || '';
    return span;
  }

  function hydrateIcons(root = document) {
    $$('[data-icon]', root).forEach((element) => {
      element.classList.add('icon');
      setIcon(element, element.dataset.icon);
      element.removeAttribute('data-icon');
    });
  }

  /* ------------------------------------------------------------------------
     Estado
     ------------------------------------------------------------------------ */

  const state = {
    songs: [],
    filtered: [],
    queue: [],
    currentId: null,
    shuffle: false,
    repeat: 'off',
    uploads: [],
    coverFile: null,
    coverPreviewUrl: null,
    busy: false,
    adminRequired: false,
    adminKey: readSession('mm_admin_key') || '',
    counted: false,
    siteName: 'Mi Música',
    maxFileMB: 100,
  };

  const audio = $('#audio');
  const player = $('#player');
  const songGrid = $('#songGrid');
  const emptyState = $('#emptyState');
  const searchInput = $('#searchInput');
  const sortSelect = $('#sortSelect');
  const uploadDialog = $('#uploadDialog');
  const dropzone = $('#dropzone');
  const fileInput = $('#fileInput');
  const coverInput = $('#coverInput');
  const coverPreviewImg = $('#coverPreviewImg');
  const removeCoverBtn = $('#removeCoverBtn');
  const adminKeyField = $('#adminKeyField');
  const adminKeyInput = $('#adminKeyInput');
  const uploadList = $('#uploadList');
  const uploadFields = $('#uploadFields');
  const submitUploadBtn = $('#submitUploadBtn');
  const submitUploadLabel = $('#submitUploadLabel');
  const playerPlayBtn = $('#playBtn');
  const seekRange = $('#seekRange');
  const volumeRange = $('#volumeRange');
  const muteBtn = $('#muteBtn');
  const shuffleBtn = $('#shuffleBtn');
  const repeatBtn = $('#repeatBtn');
  const nowTitle = $('#npTitle');
  const nowArtist = $('#npArtist');
  const npCoverImg = $('#npCoverImg');
  const npCoverFallback = $('#npCoverFallback');
  const heroNowTitle = $('#heroNowTitle');
  const vinylTitle = $('#vinylTitle');
  const toasts = $('#toasts');

  const numberFormat = new Intl.NumberFormat('es');
  const collator = new Intl.Collator('es', { sensitivity: 'base', numeric: true });

  /* ------------------------------------------------------------------------
     Utilidades
     ------------------------------------------------------------------------ */

  function readSession(key) {
    try {
      return sessionStorage.getItem(key);
    } catch {
      return null;
    }
  }

  function writeSession(key, value) {
    try {
      sessionStorage.setItem(key, value);
    } catch {
      /* sin almacenamiento disponible */
    }
  }

  function removeSession(key) {
    try {
      sessionStorage.removeItem(key);
    } catch {
      /* sin almacenamiento disponible */
    }
  }

  function normalize(text) {
    return String(text || '')
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .toLowerCase()
      .trim();
  }

  function formatTime(seconds) {
    if (!Number.isFinite(seconds) || seconds < 0) return '0:00';
    const total = Math.floor(seconds);
    const hours = Math.floor(total / 3600);
    const minutes = Math.floor((total % 3600) / 60);
    const secs = total % 60;
    if (hours > 0) {
      return `${hours}:${String(minutes).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
    }
    return `${minutes}:${String(secs).padStart(2, '0')}`;
  }

  function formatTotalDuration(seconds) {
    if (!seconds || seconds < 1) return '0 min';
    if (seconds < 60) return '< 1 min';
    const totalMinutes = Math.round(seconds / 60);
    if (totalMinutes < 60) return `${totalMinutes} min`;
    const hours = Math.floor(totalMinutes / 60);
    const minutes = totalMinutes % 60;
    return minutes ? `${hours} h ${minutes} min` : `${hours} h`;
  }

  function formatSize(bytes) {
    if (!Number.isFinite(bytes) || bytes <= 0) return '—';
    if (bytes < 1024 * 1024) return `${Math.max(1, Math.round(bytes / 1024))} KB`;
    const mb = bytes / (1024 * 1024);
    return `${mb.toFixed(mb >= 10 ? 0 : 1).replace('.0', '')} MB`;
  }

  function hashHue(text) {
    let hash = 0;
    for (let i = 0; i < text.length; i += 1) {
      hash = (hash * 31 + text.charCodeAt(i)) % 360;
    }
    return hash;
  }

  function titleFromFilename(filename) {
    return String(filename || 'Canción')
      .replace(/\.[^.]+$/, '')
      .replace(/[_]+/g, ' ')
      .replace(/\s+/g, ' ')
      .trim() || 'Canción sin título';
  }

  function isAudioFile(file) {
    return /\.(mp3|m4a|aac|ogg|oga|opus|wav|flac|webm)$/i.test(file.name)
      || (file.type || '').startsWith('audio/');
  }

  function uniqueId() {
    return `u${Date.now().toString(36)}${Math.random().toString(36).slice(2, 8)}`;
  }

  function setRangeFill(range, percent) {
    range.style.setProperty('--fill', `${Math.max(0, Math.min(100, percent))}%`);
  }

  function toast(message, type = 'info') {
    while (toasts.children.length >= 4) {
      toasts.firstElementChild?.remove();
    }

    const node = document.createElement('div');
    node.className = `toast ${type}`;
    node.append(icon(type === 'success' ? 'check' : type === 'error' ? 'alert' : 'music'));
    const text = document.createElement('span');
    text.textContent = message;
    node.append(text);
    toasts.append(node);

    setTimeout(() => {
      node.classList.add('out');
      setTimeout(() => node.remove(), 400);
    }, 4200);
  }

  const currentSong = () => state.songs.find((song) => song.id === state.currentId) || null;

  /* ------------------------------------------------------------------------
     Carga de la biblioteca
     ------------------------------------------------------------------------ */

  function applySiteConfig(config = {}) {
    state.siteName = config.siteName || 'Mi Música';
    state.adminRequired = Boolean(config.adminRequired);
    state.maxFileMB = Number(config.maxFileMB) || 100;

    $('#brandName').textContent = state.siteName;
    $('#footerName').textContent = state.siteName;
    vinylTitle.textContent = state.siteName.toUpperCase();
    document.title = `${state.siteName} · Tu biblioteca musical`;

    $('#dropHint').textContent = `MP3, M4A, AAC, WAV, FLAC, OGG, OPUS · máx. ${config.maxFileMB || 100} MB por archivo`;
    adminKeyField.hidden = !state.adminRequired;
    if (state.adminRequired && state.adminKey) {
      adminKeyInput.value = state.adminKey;
    }
  }

  async function loadLibrary({ silent = false } = {}) {
    try {
      const response = await fetch('/api/songs', { headers: { Accept: 'application/json' } });
      if (!response.ok) throw new Error(`Error ${response.status}`);
      const data = await response.json();

      state.songs = Array.isArray(data.songs) ? data.songs : [];
      applySiteConfig(data.config);
      render();
    } catch (error) {
      console.error(error);
      songGrid.replaceChildren();
      renderEmptyState({
        title: 'No se pudo cargar la biblioteca',
        text: 'Comprueba que el servidor esté encendido y vuelve a intentarlo.',
        label: 'Reintentar',
        iconName: 'alert',
        action: () => loadLibrary(),
      });
      if (!silent) toast('No se pudo conectar con el servidor.', 'error');
    }
  }

  function render() {
    renderStats();
    renderLibrary();
    updatePlayingUI();
  }

  function renderStats() {
    const count = state.songs.length;
    const duration = state.songs.reduce((total, song) => total + (song.duration || 0), 0);
    const plays = state.songs.reduce((total, song) => total + (song.plays || 0), 0);

    $('#statSongs').textContent = numberFormat.format(count);
    $('#statDuration').textContent = formatTotalDuration(duration);
    $('#statPlays').textContent = numberFormat.format(plays);

    const subtitle = $('#librarySubtitle');
    if (count === 0) {
      subtitle.textContent = 'Aún no hay canciones. Sube la primera y empieza a sonar.';
    } else {
      subtitle.textContent = `${count} canción${count === 1 ? '' : 'es'} · ${formatTotalDuration(duration)} de música`;
    }
  }

  function sortSongs(list) {
    const sorted = [...list];
    switch (sortSelect.value) {
      case 'title':
        sorted.sort((a, b) => collator.compare(a.title, b.title));
        break;
      case 'artist':
        sorted.sort((a, b) => collator.compare(a.artist, b.artist) || collator.compare(a.title, b.title));
        break;
      case 'plays':
        sorted.sort((a, b) => (b.plays || 0) - (a.plays || 0));
        break;
      case 'duration':
        sorted.sort((a, b) => (b.duration || 0) - (a.duration || 0));
        break;
      default:
        sorted.sort((a, b) => new Date(b.uploadedAt) - new Date(a.uploadedAt));
    }
    return sorted;
  }

  function renderLibrary() {
    const query = normalize(searchInput.value);
    const filtered = state.songs.filter((song) => {
      if (!query) return true;
      return normalize(`${song.title} ${song.artist}`).includes(query);
    });

    state.filtered = sortSongs(filtered);
    songGrid.replaceChildren();

    if (state.songs.length === 0) {
      renderEmptyState({
        title: 'Tu biblioteca está esperando',
        text: 'Sube tus canciones en MP3, M4A, WAV, FLAC u OGG. Se guardarán en tu servidor y podrás escucharlas desde cualquier navegador.',
        label: 'Subir mi primera canción',
        iconName: 'music',
        action: openUpload,
      });
      return;
    }

    if (state.filtered.length === 0) {
      renderEmptyState({
        title: 'Sin resultados',
        text: `No encontramos canciones que coincidan con “${searchInput.value.trim()}”. Prueba con otro título o artista.`,
        label: 'Limpiar búsqueda',
        iconName: 'search',
        action: () => {
          searchInput.value = '';
          renderLibrary();
          searchInput.focus();
        },
      });
      return;
    }

    emptyState.hidden = true;
    const fragment = document.createDocumentFragment();
    state.filtered.forEach((song, index) => {
      fragment.append(createSongCard(song, index));
    });
    songGrid.append(fragment);
    updatePlayingUI();
  }

  function renderEmptyState({ title, text, label, action, iconName = 'music' }) {
    emptyState.hidden = false;
    $('#emptyTitle').textContent = title;
    $('#emptyText').textContent = text;

    const actionButton = $('#emptyAction');
    actionButton.replaceChildren(icon(iconName), Object.assign(document.createElement('span'), { textContent: label }));
    actionButton.onclick = action;
  }

  function createSongCard(song, index) {
    const card = document.createElement('article');
    card.className = 'song-card';
    card.dataset.id = song.id;
    card.style.animationDelay = `${Math.min(index * 30, 300)}ms`;

    const cover = document.createElement('div');
    cover.className = 'song-cover';

    if (song.coverUrl) {
      const image = document.createElement('img');
      image.src = song.coverUrl;
      image.alt = '';
      image.loading = 'lazy';
      cover.append(image);
    } else {
      const fallback = document.createElement('div');
      fallback.className = 'cover-fallback';
      const hue = hashHue(song.id);
      fallback.style.background = `linear-gradient(135deg, hsl(${hue} 62% 52%), hsl(${(hue + 70) % 360} 58% 34%))`;
      fallback.append(icon('music'));
      cover.append(fallback);
    }

    const playButton = document.createElement('button');
    playButton.type = 'button';
    playButton.className = 'card-play';
    playButton.setAttribute('aria-label', `Reproducir ${song.title}`);
    playButton.append(icon('play'));
    playButton.addEventListener('click', (event) => {
      event.stopPropagation();
      if (state.currentId === song.id) {
        togglePlay();
      } else {
        playSong(song);
      }
    });

    const duration = document.createElement('span');
    duration.className = 'duration-badge';
    duration.textContent = song.duration ? formatTime(song.duration) : '—';
    cover.append(playButton, duration);

    const actions = document.createElement('div');
    actions.className = 'card-actions';

    const download = document.createElement('a');
    download.className = 'card-action';
    download.href = song.downloadUrl;
    download.download = '';
    download.title = 'Descargar';
    download.setAttribute('aria-label', `Descargar ${song.title}`);
    download.append(icon('download'));
    download.addEventListener('click', (event) => event.stopPropagation());

    const remove = document.createElement('button');
    remove.type = 'button';
    remove.className = 'card-action';
    remove.title = 'Borrar';
    remove.setAttribute('aria-label', `Borrar ${song.title}`);
    remove.append(icon('trash'));
    remove.addEventListener('click', (event) => {
      event.stopPropagation();
      deleteSong(song);
    });

    actions.append(download, remove);
    cover.append(actions);

    const info = document.createElement('div');
    info.className = 'song-info';

    const title = document.createElement('h3');
    title.className = 'song-title';
    title.textContent = song.title;

    const artist = document.createElement('p');
    artist.className = 'song-artist';
    artist.textContent = song.artist;

    const meta = document.createElement('div');
    meta.className = 'song-meta';

    const plays = document.createElement('span');
    plays.append(icon('play'), Object.assign(document.createElement('span'), {
      className: 'play-count',
      textContent: numberFormat.format(song.plays || 0),
    }));

    const size = document.createElement('span');
    size.textContent = formatSize(song.size);

    meta.append(plays, size);
    info.append(title, artist, meta);
    card.append(cover, info);

    card.addEventListener('click', () => {
      if (state.currentId === song.id) {
        togglePlay();
      } else {
        playSong(song);
      }
    });

    return card;
  }

  function updatePlayingUI() {
    $$('.song-card').forEach((card) => {
      const isCurrent = card.dataset.id === state.currentId;
      card.classList.toggle('playing', isCurrent);
      const iconNode = card.querySelector('.card-play .icon');
      if (iconNode) setIcon(iconNode, isCurrent && !audio.paused ? 'pause' : 'play');
    });

    const playIcon = playerPlayBtn.querySelector('.icon');
    setIcon(playIcon, audio.paused ? 'play' : 'pause');
    playerPlayBtn.setAttribute('aria-label', audio.paused ? 'Reproducir' : 'Pausar');
    playerPlayBtn.title = audio.paused ? 'Reproducir' : 'Pausar';
  }

  function showSkeletons() {
    songGrid.replaceChildren();
    for (let i = 0; i < 8; i += 1) {
      const card = document.createElement('div');
      card.className = 'skeleton-card';
      const cover = document.createElement('div');
      cover.className = 'skeleton-cover';
      const line = document.createElement('div');
      line.className = 'skeleton-line';
      const shortLine = document.createElement('div');
      shortLine.className = 'skeleton-line short';
      card.append(cover, line, shortLine);
      songGrid.append(card);
    }
  }

  /* ------------------------------------------------------------------------
     Reproductor
     ------------------------------------------------------------------------ */

  function playSong(song) {
    if (!song) return;

    const allIds = state.songs.map((item) => item.id);
    const visibleIds = state.filtered.length ? state.filtered.map((item) => item.id) : allIds;
    state.queue = visibleIds.includes(song.id) ? visibleIds : allIds;
    state.currentId = song.id;
    state.counted = false;

    updateNowPlaying(song);

    audio.src = song.streamUrl;
    player.classList.add('visible');
    document.body.classList.add('has-player');

    const promise = audio.play();
    if (promise) {
      promise.catch(() => {
        toast('No se pudo iniciar la reproducción. Inténtalo de nuevo.', 'error');
        updatePlayingUI();
      });
    }
  }

  function updateNowPlaying(song) {
    nowTitle.textContent = song.title;
    nowArtist.textContent = song.artist;
    heroNowTitle.textContent = song.title;

    if (song.coverUrl) {
      npCoverImg.src = song.coverUrl;
      npCoverImg.hidden = false;
      npCoverFallback.hidden = true;
    } else {
      npCoverImg.removeAttribute('src');
      npCoverImg.hidden = true;
      npCoverFallback.hidden = false;
    }

    $('#currentTime').textContent = '0:00';
    $('#totalTime').textContent = song.duration ? formatTime(song.duration) : '0:00';
    seekRange.value = '0';
    seekRange.disabled = !song.duration;
    setRangeFill(seekRange, 0);
    document.title = `${song.title} · ${song.artist}`;
    updateMediaMetadata(song);
  }

  function togglePlay() {
    if (!state.currentId) {
      const list = searchInput.value.trim() ? state.filtered : state.songs;
      if (list.length) playSong(list[0]);
      return;
    }

    if (audio.paused) {
      audio.play().catch(() => toast('No se pudo reanudar la canción.', 'error'));
    } else {
      audio.pause();
    }
  }

  function playNext(automatic = false) {
    if (!state.queue.length) return;
    const queue = state.queue;
    let nextId = null;

    if (state.shuffle && queue.length > 1) {
      const options = queue.filter((id) => id !== state.currentId);
      nextId = options[Math.floor(Math.random() * options.length)];
    } else {
      const index = queue.indexOf(state.currentId);
      if (index + 1 < queue.length) {
        nextId = queue[index + 1];
      } else if (state.repeat === 'all' || !automatic) {
        nextId = queue[0];
      } else {
        audio.pause();
        audio.currentTime = 0;
        updateProgress();
        updatePlayingUI();
        return;
      }
    }

    const song = state.songs.find((item) => item.id === nextId);
    if (song) playSong(song);
  }

  function playPrevious() {
    if (!state.currentId) return;
    if ((audio.currentTime || 0) > 3) {
      audio.currentTime = 0;
      updateProgress();
      return;
    }

    const queue = state.queue;
    if (!queue.length) return;

    let previousId;
    if (state.shuffle && queue.length > 1) {
      const options = queue.filter((id) => id !== state.currentId);
      previousId = options[Math.floor(Math.random() * options.length)];
    } else {
      const index = queue.indexOf(state.currentId);
      previousId = queue[(index - 1 + queue.length) % queue.length];
    }

    const song = state.songs.find((item) => item.id === previousId);
    if (song) playSong(song);
  }

  function seekBy(seconds) {
    if (!state.currentId || !Number.isFinite(audio.duration) || audio.duration <= 0) return;
    audio.currentTime = Math.min(Math.max(audio.currentTime + seconds, 0), audio.duration);
    updateProgress();
  }

  function updateProgress() {
    const song = currentSong();
    const duration = Number.isFinite(audio.duration) && audio.duration > 0
      ? audio.duration
      : (song?.duration || 0);
    const current = Number.isFinite(audio.currentTime) ? audio.currentTime : 0;
    const percent = duration > 0 ? (current / duration) * 100 : 0;

    $('#currentTime').textContent = formatTime(current);
    $('#totalTime').textContent = formatTime(duration);
    seekRange.disabled = !(duration > 0);
    if (!seekRange.matches(':active')) {
      seekRange.value = String(Math.round(percent * 10));
    }
    setRangeFill(seekRange, percent);
  }

  async function registerPlay(id) {
    try {
      const response = await fetch(`/api/songs/${encodeURIComponent(id)}/play`, { method: 'POST' });
      if (!response.ok) return;
      const data = await response.json();
      const song = state.songs.find((item) => item.id === id);
      if (song) song.plays = data.plays || 0;
      renderStats();
      $$('.song-card').forEach((card) => {
        if (card.dataset.id === id) {
          const count = card.querySelector('.play-count');
          if (count) count.textContent = numberFormat.format(song?.plays || 0);
        }
      });
    } catch {
      /* el contador no es crítico */
    }
  }

  function updateMediaMetadata(song) {
    if (!('mediaSession' in navigator) || !('MediaMetadata' in window)) return;
    try {
      navigator.mediaSession.metadata = new MediaMetadata({
        title: song.title,
        artist: song.artist,
        album: state.siteName,
        artwork: song.coverUrl
          ? [{ src: new URL(song.coverUrl, window.location.href).href, sizes: '512x512' }]
          : [],
      });
    } catch {
      /* Media Session no disponible */
    }
  }

  function updateMediaState(playbackState) {
    if (!('mediaSession' in navigator)) return;
    try {
      navigator.mediaSession.playbackState = playbackState;
    } catch {
      /* no soportado */
    }
  }

  function setVolumeIcon() {
    const silent = audio.muted || audio.volume === 0;
    setIcon(muteBtn.querySelector('.icon'), silent ? 'volumeX' : 'volume');
    muteBtn.title = silent ? 'Activar sonido' : 'Silenciar';
    muteBtn.setAttribute('aria-label', silent ? 'Activar sonido' : 'Silenciar');
  }

  function updateRepeatButton() {
    const active = state.repeat !== 'off';
    repeatBtn.classList.toggle('active', active);
    repeatBtn.setAttribute('aria-pressed', String(active));
    setIcon(repeatBtn.querySelector('.icon'), state.repeat === 'one' ? 'repeat1' : 'repeat');
    const label = state.repeat === 'one'
      ? 'Repetir: una canción'
      : state.repeat === 'all'
        ? 'Repetir: toda la lista'
        : 'Repetir: desactivado';
    repeatBtn.title = label;
    repeatBtn.setAttribute('aria-label', label);
  }

  function updateShuffleButton() {
    shuffleBtn.classList.toggle('active', state.shuffle);
    shuffleBtn.setAttribute('aria-pressed', String(state.shuffle));
    const label = state.shuffle ? 'Aleatorio: activado' : 'Aleatorio: desactivado';
    shuffleBtn.title = label;
    shuffleBtn.setAttribute('aria-label', label);
  }

  /* ------------------------------------------------------------------------
     Subida de canciones
     ------------------------------------------------------------------------ */

  function openUpload() {
    if (!uploadDialog.open) {
      uploadDialog.showModal();
      document.body.classList.add('modal-open');
    }
  }

  function closeUpload() {
    if (state.busy) return;
    uploadDialog.close();
  }

  function syncUploadState() {
    const pending = state.uploads.filter((item) => item.status !== 'done');
    submitUploadBtn.disabled = state.busy || pending.length === 0;
    $('#closeUploadBtn').disabled = state.busy;
    $('#cancelUploadBtn').disabled = state.busy;

    if (state.busy) {
      submitUploadLabel.textContent = 'Subiendo…';
      return;
    }

    if (pending.length === 0) {
      submitUploadLabel.textContent = 'Subir canciones';
    } else if (pending.length === 1) {
      submitUploadLabel.textContent = 'Subir canción';
    } else {
      submitUploadLabel.textContent = `Subir ${pending.length} canciones`;
    }
  }

  function addFiles(fileList) {
    if (state.busy) return;
    const files = Array.from(fileList || []);
    const maxBytes = state.maxFileMB * 1024 * 1024;
    let added = 0;

    for (const file of files) {
      if (!isAudioFile(file)) {
        toast(`“${file.name}” no es un archivo de audio compatible.`, 'error');
        continue;
      }
      if (file.size > maxBytes) {
        toast(`“${file.name}” supera el límite de tamaño.`, 'error');
        continue;
      }
      const duplicate = state.uploads.some((item) => item.file.name === file.name
        && item.file.size === file.size
        && item.file.lastModified === file.lastModified);
      if (duplicate) continue;

      const item = {
        uid: uniqueId(),
        file,
        title: titleFromFilename(file.name),
        duration: null,
        progress: 0,
        status: 'pending',
      };

      state.uploads.push(item);
      added += 1;

      readDuration(file).then((duration) => {
        item.duration = duration;
        updateUploadRow(item);
      });
    }

    if (added > 0) {
      renderUploadList();
      syncUploadState();
    }
  }

  function readDuration(file) {
    return new Promise((resolve) => {
      const url = URL.createObjectURL(file);
      const probe = new Audio();
      let settled = false;

      const finish = (value) => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        URL.revokeObjectURL(url);
        resolve(value);
      };

      const timer = setTimeout(() => finish(null), 10000);
      probe.preload = 'metadata';
      probe.addEventListener('loadedmetadata', () => {
        finish(Number.isFinite(probe.duration) && probe.duration > 0 ? Math.round(probe.duration) : null);
      });
      probe.addEventListener('error', () => finish(null));
      probe.src = url;
    });
  }

  function renderUploadList() {
    uploadList.replaceChildren();
    for (const item of state.uploads) {
      const row = createUploadRow(item);
      uploadList.append(row);
      updateUploadRow(item);
    }
    uploadFields.hidden = state.uploads.length === 0;
    syncUploadState();
  }

  function createUploadRow(item) {
    const row = document.createElement('div');
    row.className = 'upload-item';
    row.dataset.uid = item.uid;

    const fileIcon = document.createElement('span');
    fileIcon.className = 'upload-file-icon';
    fileIcon.append(icon('music'));

    const main = document.createElement('div');
    main.className = 'upload-main';

    const titleInput = document.createElement('input');
    titleInput.type = 'text';
    titleInput.className = 'upload-title';
    titleInput.maxLength = 150;
    titleInput.value = item.title;
    titleInput.setAttribute('aria-label', `Título de ${item.file.name}`);
    titleInput.addEventListener('input', () => {
      item.title = titleInput.value;
    });

    const meta = document.createElement('div');
    meta.className = 'upload-meta';
    const filename = document.createElement('span');
    filename.className = 'upload-filename';
    filename.textContent = item.file.name;
    filename.title = item.file.name;
    const size = document.createElement('span');
    size.textContent = formatSize(item.file.size);
    const duration = document.createElement('span');
    duration.className = 'upload-duration';
    duration.textContent = item.duration ? formatTime(item.duration) : '—';
    meta.append(filename, size, duration);

    main.append(titleInput, meta);

    const removeButton = document.createElement('button');
    removeButton.type = 'button';
    removeButton.className = 'icon-btn upload-remove';
    removeButton.title = 'Quitar de la lista';
    removeButton.setAttribute('aria-label', 'Quitar de la lista');
    removeButton.append(icon('close'));
    removeButton.addEventListener('click', () => {
      if (state.busy) return;
      state.uploads = state.uploads.filter((entry) => entry.uid !== item.uid);
      renderUploadList();
      syncUploadState();
    });

    const progressWrap = document.createElement('div');
    progressWrap.className = 'upload-progress-wrap';
    const progress = document.createElement('div');
    progress.className = 'upload-progress';
    const bar = document.createElement('div');
    bar.className = 'upload-progress-bar';
    progress.append(bar);
    const status = document.createElement('span');
    status.className = 'upload-status';
    progressWrap.append(progress, status);

    row.append(fileIcon, main, removeButton, progressWrap);
    updateUploadRow(item);
    return row;
  }

  function updateUploadRow(item) {
    const row = uploadList.querySelector(`.upload-item[data-uid="${item.uid}"]`);
    if (!row) return;

    row.classList.toggle('error', item.status === 'error');
    row.classList.toggle('done', item.status === 'done');

    const bar = row.querySelector('.upload-progress-bar');
    if (bar) bar.style.width = `${item.status === 'done' ? 100 : item.progress}%`;

    const status = row.querySelector('.upload-status');
    if (status) {
      status.textContent = item.status === 'uploading'
        ? `${item.progress}%`
        : item.status === 'done'
          ? 'Subida'
          : item.status === 'error'
            ? 'Error'
            : 'Listo';
    }

    const duration = row.querySelector('.upload-duration');
    if (duration) duration.textContent = item.duration ? formatTime(item.duration) : '—';

    const titleInput = row.querySelector('.upload-title');
    if (titleInput && document.activeElement !== titleInput) titleInput.value = item.title;

    const removeButton = row.querySelector('.upload-remove');
    if (removeButton) removeButton.disabled = state.busy || item.status === 'uploading' || item.status === 'done';
  }

  function uploadFile(item, adminKey) {
    return new Promise((resolve, reject) => {
      const formData = new FormData();
      formData.append('audio', item.file, item.file.name);
      formData.append('title', item.title.trim() || titleFromFilename(item.file.name));
      formData.append('artist', $('#artistInput').value.trim());
      if (item.duration) formData.append('duration', String(item.duration));
      if (state.coverFile) formData.append('cover', state.coverFile, state.coverFile.name);

      const xhr = new XMLHttpRequest();
      xhr.open('POST', '/api/songs');
      xhr.setRequestHeader('Accept', 'application/json');
      if (adminKey) xhr.setRequestHeader('x-admin-key', adminKey);

      xhr.upload.addEventListener('progress', (event) => {
        if (!event.lengthComputable) return;
        item.progress = Math.min(99, Math.round((event.loaded / event.total) * 100));
        updateUploadRow(item);
      });

      xhr.addEventListener('load', () => {
        let data = null;
        try {
          data = JSON.parse(xhr.responseText);
        } catch {
          data = null;
        }

        if (xhr.status >= 200 && xhr.status < 300 && data) {
          item.progress = 100;
          resolve(data);
          return;
        }

        const error = new Error(data?.error || `No se pudo subir la canción (error ${xhr.status}).`);
        error.status = xhr.status;
        reject(error);
      });

      xhr.addEventListener('error', () => reject(new Error('No se pudo conectar con el servidor.')));
      xhr.addEventListener('abort', () => reject(new Error('Subida cancelada.')));

      xhr.send(formData);
    });
  }

  async function submitUploads() {
    if (state.busy) return;

    const pending = state.uploads.filter((item) => item.status !== 'done');
    if (pending.length === 0) {
      toast('Selecciona al menos una canción.', 'error');
      return;
    }

    const key = adminKeyInput.value.trim() || state.adminKey;
    if (state.adminRequired && !key) {
      toast('Escribe la clave de administrador para subir canciones.', 'error');
      adminKeyInput.focus();
      return;
    }

    if (key) {
      state.adminKey = key;
      writeSession('mm_admin_key', key);
    }

    state.busy = true;
    syncUploadState();

    let uploaded = 0;
    let failed = 0;

    for (let index = 0; index < pending.length; index += 1) {
      const item = pending[index];
      item.status = 'uploading';
      item.progress = 0;
      item.error = null;
      updateUploadRow(item);
      submitUploadLabel.textContent = `Subiendo ${index + 1} de ${pending.length}…`;

      try {
        const song = await uploadFile(item, key);
        item.status = 'done';
        item.progress = 100;
        uploaded += 1;
        state.songs.unshift(song);
        updateUploadRow(item);
      } catch (error) {
        item.status = 'error';
        item.progress = 0;
        failed += 1;
        updateUploadRow(item);
        toast(error.message, 'error');

        if (error.status === 401) {
          state.adminKey = '';
          removeSession('mm_admin_key');
          pending.slice(index + 1).forEach((rest) => {
            rest.status = 'pending';
            updateUploadRow(rest);
          });
          break;
        }
      }
    }

    state.busy = false;

    if (uploaded > 0) {
      render();
    }

    if (uploaded > 0 && failed === 0) {
      toast(`${uploaded} canción${uploaded === 1 ? '' : 'es'} subida${uploaded === 1 ? '' : 's'} correctamente.`, 'success');
      setTimeout(() => {
        closeUpload();
        document.getElementById('library').scrollIntoView({ behavior: 'smooth', block: 'start' });
      }, 550);
      return;
    }

    if (uploaded > 0 && failed > 0) {
      toast(`${uploaded} subida(s) y ${failed} con error. Revisa la lista.`, 'error');
    } else if (failed > 0) {
      toast('No se pudo subir ninguna canción.', 'error');
    }

    syncUploadState();
  }

  function resetUploadForm() {
    state.uploads = [];
    state.coverFile = null;
    if (state.coverPreviewUrl) {
      URL.revokeObjectURL(state.coverPreviewUrl);
      state.coverPreviewUrl = null;
    }
    coverPreviewImg.hidden = true;
    coverPreviewImg.removeAttribute('src');
    removeCoverBtn.hidden = true;
    $('#artistInput').value = '';
    $('#coverInput').value = '';
    fileInput.value = '';
    adminKeyInput.value = state.adminKey || '';
    renderUploadList();
    uploadFields.hidden = true;
    syncUploadState();
  }

  function setCover(file) {
    if (!file) return;
    if (state.busy) return;
    if (!/^image\//.test(file.type) && !/\.(jpe?g|png|webp|gif)$/i.test(file.name)) {
      toast('La portada debe ser una imagen JPG, PNG o WebP.', 'error');
      return;
    }
    if (file.size > 8 * 1024 * 1024) {
      toast('La portada supera el límite de 8 MB.', 'error');
      return;
    }

    if (state.coverPreviewUrl) URL.revokeObjectURL(state.coverPreviewUrl);
    state.coverFile = file;
    state.coverPreviewUrl = URL.createObjectURL(file);
    coverPreviewImg.src = state.coverPreviewUrl;
    coverPreviewImg.hidden = false;
    removeCoverBtn.hidden = false;
  }

  function clearCover() {
    if (state.busy) return;
    if (state.coverPreviewUrl) {
      URL.revokeObjectURL(state.coverPreviewUrl);
      state.coverPreviewUrl = null;
    }
    state.coverFile = null;
    coverPreviewImg.hidden = true;
    coverPreviewImg.removeAttribute('src');
    coverInput.value = '';
    removeCoverBtn.hidden = true;
  }

  /* ------------------------------------------------------------------------
     Borrado
     ------------------------------------------------------------------------ */

  async function deleteRequest(id, key) {
    const headers = { Accept: 'application/json' };
    if (key) headers['x-admin-key'] = key;

    const response = await fetch(`/api/songs/${encodeURIComponent(id)}`, {
      method: 'DELETE',
      headers,
    });

    if (!response.ok) {
      let data = null;
      try {
        data = await response.json();
      } catch {
        data = null;
      }
      const error = new Error(data?.error || `No se pudo borrar la canción (error ${response.status}).`);
      error.status = response.status;
      throw error;
    }
  }

  async function deleteSong(song) {
    const confirmed = window.confirm(`¿Borrar “${song.title}” de tu biblioteca?\n\nEl archivo se eliminará del servidor y no se puede deshacer.`);
    if (!confirmed) return;

    try {
      try {
        await deleteRequest(song.id, state.adminKey);
      } catch (error) {
        if (error.status !== 401) throw error;
        const key = window.prompt('Esta biblioteca está protegida. Escribe la clave de administrador:');
        if (key === null) return;
        await deleteRequest(song.id, key.trim());
        state.adminKey = key.trim();
        writeSession('mm_admin_key', state.adminKey);
      }

      state.songs = state.songs.filter((item) => item.id !== song.id);
      state.queue = state.queue.filter((id) => id !== song.id);
      if (state.currentId === song.id) resetPlayer();
      render();
      toast('Canción eliminada.', 'success');
    } catch (error) {
      toast(error.message, 'error');
    }
  }

  function resetPlayer() {
    audio.pause();
    audio.removeAttribute('src');
    audio.load();
    state.currentId = null;
    state.queue = [];
    state.counted = false;
    player.classList.remove('visible');
    document.body.classList.remove('has-player');
    nowTitle.textContent = 'Elige una canción';
    nowArtist.textContent = 'Tu biblioteca te espera';
    npCoverImg.hidden = true;
    npCoverImg.removeAttribute('src');
    npCoverFallback.hidden = false;
    heroNowTitle.textContent = 'Tu próxima canción';
    resetVinylTitle();
    $('#currentTime').textContent = '0:00';
    $('#totalTime').textContent = '0:00';
    seekRange.value = '0';
    seekRange.disabled = true;
    setRangeFill(seekRange, 0);
    document.title = `${state.siteName} · Tu biblioteca musical`;
    if ('mediaSession' in navigator) {
      try {
        navigator.mediaSession.metadata = null;
        navigator.mediaSession.playbackState = 'none';
      } catch {
        /* no soportado */
      }
    }
    updatePlayingUI();
  }

  function resetVinylTitle() {
    vinylTitle.textContent = state.siteName.toUpperCase();
  }

  /* ------------------------------------------------------------------------
     Eventos
     ------------------------------------------------------------------------ */

  function setupEvents() {
    hydrateIcons();
    applySiteConfig({});

    $$('[data-open-upload]').forEach((button) => button.addEventListener('click', openUpload));

    $('#playAllBtn').addEventListener('click', () => {
      const list = searchInput.value.trim() ? state.filtered : state.songs;
      if (!list.length) {
        toast('Sube una canción para empezar a reproducir.', 'info');
        openUpload();
        return;
      }
      playSong(list[0]);
    });

    searchInput.addEventListener('input', renderLibrary);
    sortSelect.addEventListener('change', renderLibrary);

    $('#closeUploadBtn').addEventListener('click', closeUpload);
    $('#cancelUploadBtn').addEventListener('click', closeUpload);
    $('#submitUploadBtn').addEventListener('click', submitUploads);

    uploadDialog.addEventListener('close', () => {
      document.body.classList.remove('modal-open');
      resetUploadForm();
    });

    uploadDialog.addEventListener('cancel', (event) => {
      if (state.busy) event.preventDefault();
    });

    uploadDialog.addEventListener('click', (event) => {
      if (event.target === uploadDialog) closeUpload();
    });

    dropzone.addEventListener('click', () => fileInput.click());
    dropzone.addEventListener('keydown', (event) => {
      if (event.key === 'Enter' || event.key === ' ') {
        event.preventDefault();
        fileInput.click();
      }
    });

    fileInput.addEventListener('change', () => {
      addFiles(fileInput.files);
      fileInput.value = '';
    });

    ['dragenter', 'dragover'].forEach((type) => {
      dropzone.addEventListener(type, (event) => {
        event.preventDefault();
        dropzone.classList.add('dragover');
      });
    });

    ['dragleave', 'dragend'].forEach((type) => {
      dropzone.addEventListener(type, () => dropzone.classList.remove('dragover'));
    });

    dropzone.addEventListener('drop', (event) => {
      event.preventDefault();
      dropzone.classList.remove('dragover');
      addFiles(event.dataTransfer?.files);
    });

    window.addEventListener('dragover', (event) => event.preventDefault());
    window.addEventListener('drop', (event) => event.preventDefault());

    $('#chooseCoverBtn').addEventListener('click', () => coverInput.click());
    coverInput.addEventListener('change', () => setCover(coverInput.files?.[0]));
    removeCoverBtn.addEventListener('click', clearCover);

    playerPlayBtn.addEventListener('click', togglePlay);
    $('#nextBtn').addEventListener('click', () => playNext(false));
    $('#prevBtn').addEventListener('click', playPrevious);

    shuffleBtn.addEventListener('click', () => {
      state.shuffle = !state.shuffle;
      updateShuffleButton();
    });

    repeatBtn.addEventListener('click', () => {
      state.repeat = state.repeat === 'off' ? 'all' : state.repeat === 'all' ? 'one' : 'off';
      updateRepeatButton();
    });

    seekRange.addEventListener('input', () => {
      if (!Number.isFinite(audio.duration) || audio.duration <= 0) return;
      const percent = Number(seekRange.value) / 1000;
      audio.currentTime = percent * audio.duration;
      setRangeFill(seekRange, percent * 100);
      $('#currentTime').textContent = formatTime(audio.currentTime);
    });

    let savedVolume = 1;
    try {
      const storedVolume = localStorage.getItem('mm_volume');
      if (storedVolume !== null) {
        const parsedVolume = Number(storedVolume);
        if (Number.isFinite(parsedVolume)) savedVolume = Math.min(Math.max(parsedVolume, 0), 1);
      }
    } catch {
      /* sin almacenamiento disponible */
    }
    audio.volume = savedVolume;
    volumeRange.value = String(audio.volume);
    setRangeFill(volumeRange, audio.volume * 100);
    setVolumeIcon();

    volumeRange.addEventListener('input', () => {
      audio.volume = Number(volumeRange.value);
      audio.muted = false;
      try {
        localStorage.setItem('mm_volume', String(audio.volume));
      } catch {
        /* sin almacenamiento disponible */
      }
      setRangeFill(volumeRange, audio.volume * 100);
      setVolumeIcon();
    });

    muteBtn.addEventListener('click', () => {
      if (audio.muted || audio.volume === 0) {
        audio.muted = false;
        if (audio.volume === 0) {
          audio.volume = 0.8;
          volumeRange.value = '0.8';
          setRangeFill(volumeRange, 80);
        }
      } else {
        audio.muted = true;
      }
      setVolumeIcon();
    });

    audio.addEventListener('play', () => {
      updatePlayingUI();
      updateMediaState('playing');
      if (state.currentId && !state.counted) {
        state.counted = true;
        registerPlay(state.currentId);
      }
    });

    audio.addEventListener('pause', () => {
      updatePlayingUI();
      updateMediaState('paused');
    });

    audio.addEventListener('timeupdate', updateProgress);

    audio.addEventListener('loadedmetadata', () => {
      const song = currentSong();
      if (song && Number.isFinite(audio.duration)) {
        song.duration = Math.round(audio.duration);
      }
      updateProgress();
    });

    audio.addEventListener('ended', () => {
      if (state.repeat === 'one') {
        audio.currentTime = 0;
        audio.play().catch(() => {});
        return;
      }
      playNext(true);
    });

    audio.addEventListener('error', () => {
      if (!state.currentId || !audio.getAttribute('src')) return;
      toast('No se pudo reproducir esta canción. Revisa el archivo.', 'error');
      updatePlayingUI();
    });

    if ('mediaSession' in navigator) {
      try {
        navigator.mediaSession.setActionHandler('play', () => audio.play().catch(() => {}));
        navigator.mediaSession.setActionHandler('pause', () => audio.pause());
        navigator.mediaSession.setActionHandler('previoustrack', playPrevious);
        navigator.mediaSession.setActionHandler('nexttrack', () => playNext(false));
        navigator.mediaSession.setActionHandler('seekbackward', () => seekBy(-10));
        navigator.mediaSession.setActionHandler('seekforward', () => seekBy(10));
      } catch {
        /* acciones no soportadas */
      }
    }

    document.addEventListener('keydown', (event) => {
      if (uploadDialog.open) return;
      const target = event.target;
      const tag = target?.tagName;
      if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT' || tag === 'BUTTON'
        || target?.isContentEditable) return;

      if (event.code === 'Space') {
        event.preventDefault();
        togglePlay();
      } else if (event.key === 'ArrowRight') {
        event.preventDefault();
        seekBy(5);
      } else if (event.key === 'ArrowLeft') {
        event.preventDefault();
        seekBy(-5);
      }
    });
  }

  /* ------------------------------------------------------------------------
     Inicio
     ------------------------------------------------------------------------ */

  updateRepeatButton();
  updateShuffleButton();
  setupEvents();
  showSkeletons();
  loadLibrary();
})();
